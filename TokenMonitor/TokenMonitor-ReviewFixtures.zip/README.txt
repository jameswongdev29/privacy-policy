FICTITIOUS REVIEW DATA. These API keys are invalid and must never be used with a real client.
Choose Codex and Claude directories in Token Monitor Settings.
Save current Codex account A, import Account-B.auth.json, switch to B, then Undo.
Do not point a real Codex or Claude client at these directories.
